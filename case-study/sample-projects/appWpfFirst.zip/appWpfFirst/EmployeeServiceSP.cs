﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace appWpfFirst
{
    public static class EmployeeServiceSP
    {
        public static void Create(Employee employee)
        {
            string insertString = @"employee_add";

            SqlConnection con = new SqlConnection(DbConfig.ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(insertString, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@employee_id", employee.Id);
            cmd.Parameters.AddWithValue("@employee_name", employee.Name);
            cmd.Parameters.AddWithValue("@job_title", employee.JobTitle);
            cmd.Parameters.AddWithValue("@salary", employee.Salary);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static void Update(Employee employee)
        {
            string insertString = @"employee_update";

            SqlConnection con = new SqlConnection(DbConfig.ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(insertString, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@employee_id", employee.Id);
            cmd.Parameters.AddWithValue("@employee_name", employee.Name);
            cmd.Parameters.AddWithValue("@job_title", employee.JobTitle);
            cmd.Parameters.AddWithValue("@salary", employee.Salary);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public static void Delete(int employee_id)
        {
            string insertString = @"employee_delete";

            SqlConnection con = new SqlConnection(DbConfig.ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(insertString, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@employee_id", employee_id);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static List<Employee> ReadAll()
        {
            List<Employee> employees = new List<Employee>();

            string insertString = @"employee_select";

            SqlConnection con = new SqlConnection(DbConfig.ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(insertString, con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                employees.Add(new Employee(
                    (int)reader["employee_id"],
                    (string)reader["employee_name"],
                    (string)reader["job_title"],
                    (double)reader["salary"]
                    ));
            }
            con.Close();

            return employees;
        }
    }
}
