﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace appWpfFirst
{
    public static class DbConfig
    {
        public static string ConnectionString{
            get
            {
                String str = appWpfFirst.Properties.Resources.ConnectionString;
                return str;
            }
        }
    }
}
