﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace appWpfFirst
{
    /// <summary>
    /// Interaction logic for frmEmployee.xaml
    /// </summary>
    public partial class frmEmployee : Window
    {
        public frmEmployee()
        {
            InitializeComponent();
        }


        public static frmEmployee Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new frmEmployee();
                }
                return instance;
            }
        }
        public static frmEmployee instance;

        bool isNew = true;
        public bool IsNew
        {
            get { return isNew; }
            set
            {
                isNew = value;
                LblFormStatus.Content = isNew ? "New Employee" : "Edit Employee";
                TxtID.IsReadOnly = !isNew;
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to save?", "Confirm", MessageBoxButton.YesNo)!=MessageBoxResult.Yes)
            {
                return;
            }

            Employee employee = new Employee(
                int.Parse(TxtID.Text),
                TxtName.Text,
                TxtJobTitle.Text,
                Double.Parse(TxtSalary.Text)
                );

            if (IsNew)
            {
                EmployeeService.Create(employee);
            }
            {
                EmployeeService.Update(employee);
            }

            MessageBox.Show("Employee is saved successfully.");
            lblStatus.Content = "Employee is saved successfully.";

            BtnNew_Click(null, null);
            BtnLoad_Click(null, null);
        }

        private void BtnNew_Click(object sender, EventArgs e)
        {
            TxtID.Text = string.Empty;
            TxtName.Text = string.Empty;
            TxtJobTitle.Text = string.Empty;
            TxtSalary.Text = string.Empty;

            IsNew = true;
        }

        private void BtnLoad_Click(object sender, EventArgs e)
        {
            List<Employee> employees = EmployeeService.ReadAll();
            GrdEmployees.ItemsSource = employees;
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            Employee employee = (Employee)GrdEmployees.SelectedItem;
            TxtID.Text = employee.Id.ToString();
            TxtName.Text = employee.Name;
            TxtJobTitle.Text = employee.JobTitle;
            TxtSalary.Text = employee.Salary.ToString();

            IsNew = false;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to delete?", "Confirm", MessageBoxButton.YesNo) != MessageBoxResult.Yes)
            {
                return;
            }
            Employee employee = (Employee)GrdEmployees.SelectedItem;
            EmployeeService.Delete(employee.Id);

            MessageBox.Show("Employee is deleted successfully.");
            lblStatus.Content = "Employee is deleted successfully.";

            BtnNew_Click(null, null);
            BtnLoad_Click(null, null);
        }

        private void BtnNav_Click(object sender, RoutedEventArgs e)
        {
            frmEmployeeSP.Instance.Show();
            this.Hide();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!isAppClosing)
                e.Cancel = true;
        }
        bool isAppClosing = false;
        private void btnExit_Click(object sender, EventArgs e)
        {
            isAppClosing = true;
            System.Windows.Application.Current.Shutdown();
        }
    }
}
