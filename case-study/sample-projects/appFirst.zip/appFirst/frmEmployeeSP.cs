﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace appFirst
{


    
    public partial class frmEmployeeSP : Form
    {

        public static frmEmployeeSP Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new frmEmployeeSP();
                }
                return instance;
            }
        }
        public static frmEmployeeSP instance;

        bool isNew = true;
        public bool IsNew
        {
            get { return isNew; }
            set
            {
                isNew = value;
                LblFormStatus.Text = isNew ? "New Employee" : "Edit Employee";
                TxtID.ReadOnly = !isNew;
            }
        }

       
        public frmEmployeeSP()
        {
            InitializeComponent();
        }
        

        

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure to save?","Confirm",MessageBoxButtons.YesNo)!=DialogResult.Yes)
            {
                return;
            }

            Employee employee = new Employee(
                int.Parse(TxtID.Text),
                TxtName.Text,
                TxtJobTitle.Text,
                Double.Parse(TxtSalary.Text)
                );
            
            if(IsNew)
            {
                EmployeeServiceSP.Create(employee);
            }
            {
                EmployeeServiceSP.Update(employee);
            }

            MessageBox.Show("Employee is saved successfully.");
            lblStatus.Text = "Employee is saved successfully.";

            BtnNew_Click(null,null);
            BtnLoad_Click(null, null);
        }

        private void BtnNew_Click(object sender, EventArgs e)
        {
            TxtID.Text = string.Empty;
            TxtName.Text = string.Empty;
            TxtJobTitle.Text = string.Empty;
            TxtSalary.Text = string.Empty;

            IsNew = true;
        }

        private void BtnLoad_Click(object sender, EventArgs e)
        {
            List<Employee> employees = EmployeeServiceSP.ReadAll();
            GrdEmployees.DataSource = employees;
        }
        
        private void BtnEdit_Click(object sender, EventArgs e)
        {   Employee employee = (Employee)GrdEmployees.SelectedRows[0].DataBoundItem;
            TxtID.Text = employee.Id.ToString();
            TxtName.Text = employee.Name;
            TxtJobTitle.Text = employee.JobTitle;
            TxtSalary.Text = employee.Salary.ToString();

            IsNew = false;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to delete?", "Confirm", MessageBoxButtons.YesNo) != DialogResult.Yes)
            {
                return;
            }
            Employee employee = (Employee)GrdEmployees.SelectedRows[0].DataBoundItem;
            EmployeeServiceSP.Delete(employee.Id);

            MessageBox.Show("Employee is deleted successfully.");
            lblStatus.Text = "Employee is deleted successfully.";

            BtnNew_Click(null, null);
            BtnLoad_Click(null, null);
        }

        private void btnNav_Click(object sender, EventArgs e)
        {
            frmEmployee.Instance.Show();
            this.Hide();
        }

        private void frmEmployeeSP_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(!isAppClosing)
                e.Cancel = true;
        }
        bool isAppClosing = false;
        private void btnExit_Click(object sender, EventArgs e)
        {
            isAppClosing = true;
            Application.Exit();
        }
    }
}

