﻿using EmployeeWpfMvvmApp.DataAccessObject;
using EmployeeWpfMvvmApp.Model;
using EmployeeWpfMvvmApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeWpfMvvmApp
{
    /// <summary>
    /// Interaction logic for FrmForks.xaml
    /// </summary>
    public partial class FrmForks : Window
    {
        public FrmForks()
        {
            InitializeComponent();
            mdl = (EmployeeViewModel)MyLayout.DataContext;
        }
        public static FrmForks Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new FrmForks();
                }
                return instance;
            }
        }
        public static FrmForks instance;
        private EmployeeViewModel mdl;
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

            MainWindow.Instance.Show();
            this.Hide();
        }

        private void BtnLoad_Click(object sender, RoutedEventArgs e)
        {

            ObservableCollection<EmployeeModel> employees = EmployeeDAO.ReadAll();
            mdl.EmployeesGrid = employees;
        }
    }
}
